board info:
Freescale Tower TWR-K60F120M
http://www.freescale.com/zh-Hans/webapp/sps/site/prod_summary.jsp?code=TWR-K60F120M
with:
TWR-SER
http://www.freescale.com/zh-Hans/webapp/sps/site/prod_summary.jsp?code=TWR-SER
and TWR-ELEV
http://www.freescale.com/zh-Hans/webapp/sps/site/prod_summary.jsp?code=TWR-ELEV